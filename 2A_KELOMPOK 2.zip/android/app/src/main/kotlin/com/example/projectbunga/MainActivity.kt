package com.example.projectbunga

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
