// ignore_for_file: library_private_types_in_public_api

import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';

class DataDetail extends StatefulWidget {
  final String? nama;
  final String? alamat;
  // final String? asalSekolah;
  final String? tanggalLahir;
  final String? pengalamanKerja;
  final String? noktp;
  final String? nonpwp;
  final String? linkSosmed;
  final String? ket;
  final XFile? foto;

  const DataDetail(
      {Key? key,
      this.nama,
      this.alamat,
      // this.asalSekolah,
      this.tanggalLahir,
      this.pengalamanKerja,
      this.noktp,
      this.nonpwp,
      this.linkSosmed,
      this.ket,
      this.foto})
      : super(key: key);

  @override
  _DataDetailState createState() => _DataDetailState();
}

class _DataDetailState extends State<DataDetail> {
  //savedata
  String data = '';
  saveFileData() async {
    String responseText;
    responseText = await rootBundle.loadString('lib/data_pegawai/data.txt');

    setState(() {
      data = responseText;
    });
  }

  @override
  void initState() {
    saveFileData();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Data Pendaftaran',
          textAlign: TextAlign.center,
        ),
      ),
      body: Column(
        children: [
          Text("Nama : " + widget.nama.toString()),
          Text("Alamat : " + widget.alamat.toString()),
          // Text("asal Sekolah : " + widget.asalSekolah.toString()),
          Text("Tanggal Lahir : " + widget.tanggalLahir.toString()),
          Text("Pengalaman Kerja : " + widget.pengalamanKerja.toString()),
          Text("Foto : " + widget.foto!.path.toString()),
          Text("Nomor KTP : " + widget.noktp.toString()),
          Text("Nomor NPWP : " + widget.nonpwp.toString()),
          Text("Link Sosmed : " + widget.linkSosmed.toString()),
          Text("Keterangan : " + widget.ket.toString()),
        ],
      ),
    );
  }
}

// Future<String> getFilePath() async {
//   Directory appDocumentsDirectory =
//       await getApplicationDocumentsDirectory(); // 1
//   String appDocumentsPath = appDocumentsDirectory.path; // 2
//   String filePath = '$appDocumentsPath/lib/data_pegawai/data.txt'; // 3

//   return filePath;
// }

// void saveFile() async {
//   File file = File(await getFilePath()); // 1
//   file.writeAsString(""); // 2
// }
