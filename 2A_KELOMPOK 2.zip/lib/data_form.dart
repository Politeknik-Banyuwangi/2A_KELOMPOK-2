import 'package:flutter/material.dart';
import 'data_detail.dart';
import 'package:image_picker/image_picker.dart';

enum SingingCharacter { laki, perempuan }

class form extends StatefulWidget {
  const form({Key? key}) : super(key: key);

  @override
  State<form> createState() => _form();
}

class _form extends State<form> {
  SingingCharacter? _character = SingingCharacter.laki;
  var formKey = GlobalKey<FormState>();
  TextEditingController name = TextEditingController();
  TextEditingController tempatTinggal = TextEditingController();
  // TextEditingController asal = TextEditingController();
  TextEditingController tanggal = TextEditingController();
  TextEditingController dateController = TextEditingController();
  TextEditingController ktp = TextEditingController();
  TextEditingController npwp = TextEditingController();
  TextEditingController sosmed = TextEditingController();
  TextEditingController keterangan = TextEditingController();
  List<String> listPengalamanKerja = <String>[
    '1 Tahun',
    '2 Tahun',
    '3 Tahun',
    '4 Tahun',
    '5 Tahun'
  ];

  String pengalamanKerja = '1 Tahun';
  XFile? imageFile;

  void inistate() {
    super.initState();
    dateController.text = "";
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Text(
        'Form Pendaftaran',
        textAlign: TextAlign.center,
      )),
      body: Padding(
        padding: const EdgeInsets.all(15.0),
        child: Form(
            key: formKey,
            child: SingleChildScrollView(
              child: Column(children: <Widget>[
                TextFormField(
                    controller: name,
                    keyboardType: TextInputType.text,
                    decoration: InputDecoration(
                      labelText: "Nama",
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20.0)),
                    )),
                SizedBox(
                  height: 16,
                ),
                TextFormField(
                    controller: tempatTinggal,
                    keyboardType: TextInputType.text,
                    decoration: InputDecoration(
                      labelText: "Alamat",
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20.0)),
                    )),
                SizedBox(
                  height: 16,
                ),
                // TextFormField(
                //     controller: asal,
                //     keyboardType: TextInputType.text,
                //     decoration: InputDecoration(
                //       labelText: "Asal Sekolah",
                //       border: OutlineInputBorder(
                //           borderRadius: BorderRadius.circular(20.0)),
                //     )),
                // SizedBox(
                //   height: 16,
                // ),
                TextField(
                    controller:
                        dateController, //editing controller of this TextField
                    decoration: const InputDecoration(
                        icon: Icon(Icons.calendar_today), //icon of text field
                        labelText: "Tanggal Lahir" //label text of field
                        ),
                    readOnly: true, // when true user cannot edit text
                    onTap: () async {
                      //when click we have to show the datepicker

                      DateTime? pickedDate = await showDatePicker(
                          context: context,
                          initialDate: DateTime.now(), //get today's date
                          firstDate: DateTime(
                              2000), //DateTime.now() - not to allow to choose before today.
                          lastDate: DateTime(2101));
                      if (pickedDate != null) {
                        setState(() {
                          dateController.text = pickedDate.toString();
                        });
                      } else {
                        print("Tidak Terpilih");
                      }
                    }),
                new Padding(padding: new EdgeInsets.only(top: 20.0)),
                Container(
                  child: new ListTile(
                    title: const Text('Laki-laki'),
                    leading: Radio<SingingCharacter>(
                      value: SingingCharacter.laki,
                      groupValue: _character,
                      onChanged: (SingingCharacter? value) {
                        setState(() {
                          _character = value;
                        });
                      },
                    ),
                    subtitle: new Text("Pilih ini jika anda Laki-laki"),
                  ),
                ),
                Container(
                  child: new ListTile(
                    title: const Text('Perempuan'),
                    leading: Radio<SingingCharacter>(
                      value: SingingCharacter.perempuan,
                      groupValue: _character,
                      onChanged: (SingingCharacter? value) {
                        setState(() {
                          _character = value;
                        });
                      },
                    ),
                    subtitle: new Text("Pilih ini jika anda Perempuan"),
                  ),
                ),
                SizedBox(
                  height: 16,
                ),
                Row(
                  children: [
                    Text("Pengalaman Kerja"),
                    new Padding(padding: new EdgeInsets.only(right: 30.0)),
                    DropdownButton(
                      value: listPengalamanKerja.first,
                      items: listPengalamanKerja
                          .map<DropdownMenuItem<String>>((String value) {
                        return DropdownMenuItem<String>(
                          value: value,
                          child: Text(value),
                        );
                      }).toList(),
                      onChanged: (String? newValue) {
                        setState(() {
                          pengalamanKerja = newValue!;
                        });
                      },
                    ),
                  ],
                ),
                SizedBox(
                  height: 16,
                ),
                ElevatedButton(
                    onPressed: () {
                      _getFromGallery();
                    },
                    child: Text("Pilih Foto")),
                SizedBox(
                  height: 16,
                ),
                TextFormField(
                    controller: ktp,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      labelText: "Nomor KTP",
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20.0)),
                    )),
                SizedBox(
                  height: 16,
                ),
                TextFormField(
                    controller: npwp,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      labelText: "Nomor NPWP",
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20.0)),
                    )),
                SizedBox(
                  height: 16,
                ),
                TextFormField(
                    controller: sosmed,
                    keyboardType: TextInputType.text,
                    decoration: InputDecoration(
                      labelText: "Link Sosmed",
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20.0)),
                    )),
                SizedBox(
                  height: 16,
                ),
                TextFormField(
                    controller: keterangan,
                    keyboardType: TextInputType.text,
                    decoration: InputDecoration(
                      labelText: "Keterangan",
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20.0)),
                    )),
                new Padding(padding: new EdgeInsets.only(top: 20.0)),
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton(
                          onPressed: () {
                            String nama = name.text;
                            String alamat = tempatTinggal.text;
                            // String asalSekolah = asal.text;
                            String tanggalLahir = dateController.text;
                            String noktp = ktp.text;
                            String nonpwp = npwp.text;
                            String linkSosmed = sosmed.text;
                            String ket = keterangan.text;
                            Navigator.of(context).push(MaterialPageRoute(
                                builder: (context) => DataDetail(
                                    nama: nama,
                                    alamat: alamat,
                                    // asalSekolah: asalSekolah,
                                    tanggalLahir: tanggalLahir,
                                    pengalamanKerja: pengalamanKerja,
                                    noktp: noktp,
                                    nonpwp: nonpwp,
                                    linkSosmed: linkSosmed,
                                    ket: ket,
                                    foto: imageFile)));
                          },
                          child: const Text("Simpan")),
                    ),
                    SizedBox(width: 16),
                    Expanded(
                        child: ElevatedButton(
                            onPressed: () {
                              name.clear();
                              tempatTinggal.clear();
                              // asal.clear();
                              tanggal.clear();
                              dateController.clear();
                              ktp.clear();
                              npwp.clear();
                              sosmed.clear();
                              keterangan.clear();
                            },
                            child: Text("Cancel"))),
                  ],
                ),
              ]),
            )),
      ),
    );
  }

  _getFromGallery() async {
    XFile? pickedFile =
        await ImagePicker().pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      imageFile = pickedFile;
    }
  }
}
